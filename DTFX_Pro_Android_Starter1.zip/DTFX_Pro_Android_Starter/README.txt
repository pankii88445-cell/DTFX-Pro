DTFX Pro Android starter project (v0.1 demo)

WHAT THIS BUILD CONTAINS
- Android Studio project using Kotlin + WebView
- BTC/USDT, NIFTY 50 and BANK NIFTY market selector
- 1m, 3m, 5m, 15m and 1h timeframe selector
- Candlestick chart preview using Lightweight Charts
- Demo/sample candles only

IMPORTANT
- This is a starter project, not a finished live trading app.
- No live market-data feed is connected.
- DTFX Algo Zones has NOT yet been ported from Pine Script to JavaScript.
- The next step is a faithful port of the user's exact Pine Script logic (BOS/CHoCH, swing structure, Fibonacci zones, invalidation and overlap handling).
- NIFTY/BANK NIFTY live data requires an authorized market-data provider. BTC live data also needs a data-feed connection.
- The chart library is loaded from its public CDN, so the first chart view needs internet access.

HOW TO OPEN
1. Install Android Studio.
2. Choose Open and select this DTFX_Pro_Android folder.
3. Allow Gradle sync.
4. Connect an Android phone with USB debugging enabled, or use an emulator.
5. Press Run.

Package: com.dtfxpro.app
App name: DTFX Pro
